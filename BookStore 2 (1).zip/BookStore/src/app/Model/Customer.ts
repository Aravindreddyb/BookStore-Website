export interface Customer {
  status: String;
  }
