export interface Books {
id: number;
image: string;
name: string;
price: number;
description: string;
}
